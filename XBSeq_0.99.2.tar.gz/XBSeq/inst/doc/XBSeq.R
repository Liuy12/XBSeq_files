## ------------------------------------------------------------------------
library("XBSeq")

## ------------------------------------------------------------------------
data(ExampleData)

## ------------------------------------------------------------------------
head(Observed)
head(Background)

## ------------------------------------------------------------------------
Signal <- estimateRealcount(Observed, Background)

## ------------------------------------------------------------------------
conditions <- factor(c(rep('C',3), rep('T', 3)))
XB <- XBSeqDataSet(Signal,conditions)
XB <- estimateSizeFactors( XB )
XB <-estimateSCV( XB, Observed, Background, method='pooled', sharingMode='maximum', fitType='local' )

## ------------------------------------------------------------------------
plotSCVEsts(XB)

## ------------------------------------------------------------------------
Teststas <- XBSeqTest( XB, levels(conditions)[1L], levels(conditions)[2L] )

## ------------------------------------------------------------------------
MAplot(Teststas, padj = FALSE, pcuff = 0.01, lfccuff = 1)

## ------------------------------------------------------------------------
library('DESeq')
library('ggplot2')
de <- newCountDataSet(Observed, conditions)
de <- estimateSizeFactors(de)
de <- estimateDispersions(de, method = "pooled", fitType="local")
res <- nbinomTest(de, levels(conditions)[1], levels(conditions)[2])

## ------------------------------------------------------------------------
DE_index_DESeq <- with(res, which(pval<0.01 & abs(log2FoldChange)>1))
DE_index_XBSeq <- with(Teststas, which(pval<0.01 & abs(log2FoldChange)>1))
DE_index_inters <- intersect(DE_index_DESeq, DE_index_XBSeq)
DE_index_DESeq_uniq <- setdiff(DE_index_DESeq, DE_index_XBSeq)
DE_plot <- MAplot(Teststas, padj = FALSE, pcuff = 0.01, lfccuff = 1, shape=16)
DE_plot + geom_point( data=Teststas[DE_index_inters,], aes( x=baseMean, y=log2FoldChange ), color= 'green', shape=16 ) + geom_point( data=Teststas[DE_index_DESeq_uniq,], aes( x=baseMean, y=log2FoldChange ), color= 'blue', shape=16 )

## ------------------------------------------------------------------------
sessionInfo()

