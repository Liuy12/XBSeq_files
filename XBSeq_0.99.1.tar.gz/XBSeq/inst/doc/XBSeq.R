## ------------------------------------------------------------------------
source('http://www.bioconductor.org/biocLite.R')
biocLite("XBSeq")

## ------------------------------------------------------------------------
library("XBSeq")

## ------------------------------------------------------------------------
data(ExampleData)

## ------------------------------------------------------------------------
# Observe and background are the output matrix from HTSeq
Signal <- estimateRealcount(Observed, Background)
# conditions are the design matrix for the experiment
conditions <- factor(c(rep('C',3), rep('T', 3)))
XB <- XBSeqDataSet(Signal,conditions)
XB <- estimateSizeFactors( XB )
XB <-estimateSCV( XB, Observed, Background, method='pooled', sharingMode='maximum', fitType='local' )
# Take a look at the fitting information 
plotSCVEsts(XB)

Teststas <- XBSeqTest( XB, levels(conditions)[1L], levels(conditions)[2L] )
# Plot Maplot based on test statistics
MAplot(Teststas, padj = F, pcuff = 0.01, lfccuff = 1)

## ------------------------------------------------------------------------
# Alternatively, all the codes above can be done with a wrapper function XBSeq
Teststats <- XBSeq( Observed, Background, conditions, method='pooled', sharingMode='maximum', fitType='local', pvals_only=FALSE )

## ------------------------------------------------------------------------
sessionInfo()

